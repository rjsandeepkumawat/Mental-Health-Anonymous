import streamlit as st
import numpy as np
import json
import random
import pickle
import nltk
from nltk.stem import WordNetLemmatizer

# For sklearn model loading
import pickle

# Load intents JSON
with open('intents.json') as file:
    intents = json.load(file)

# Load pickled files
words = pickle.load(open('words.pkl', 'rb'))
classes = pickle.load(open('classes.pkl', 'rb'))
model = pickle.load(open('model.pkl', 'rb'))  # Sklearn model loaded via pickle

lemmatizer = WordNetLemmatizer()

# Preprocess input sentence
def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word.lower()) for word in sentence_words]
    return sentence_words

# Convert sentence to bag of words
def bow(sentence, words):
    sentence_words = clean_up_sentence(sentence)
    bag = [0] * len(words)
    for s in sentence_words:
        for i, w in enumerate(words):
            if w == s:
                bag[i] = 1
    return np.array(bag)

# Predict intent
def predict_class(sentence):
    bow_vector = bow(sentence, words)
    res = model.predict([bow_vector])[0]
    max_prob_index = np.argmax(res)
    intent = classes[max_prob_index]
    return intent

# Get response
def get_response(intent_tag, intents_json):
    for intent in intents_json['intents']:
        if intent['tag'] == intent_tag:
            return random.choice(intent['responses'])

# Streamlit UI
def main():
    st.set_page_config(page_title="AI Menatl health Chatbot", page_icon="💬", layout="centered")

    st.markdown("""
        <style>
        body {
            background-color: #f5f7fa;
        }
        .chat-message {
            padding: 1rem;
            border-radius: 20px;
            margin: 0.5rem 0;
            display: inline-block;
            max-width: 70%;
            font-size: 1rem;
            line-height: 1.5;
            box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.1);
        }
        .user-message {
            background: linear-gradient(135deg, #b2fefa, #0ed2f7);
            color: #003366;
            text-align: right;
            margin-left: auto;
        }
        .bot-message {
            background: linear-gradient(135deg, #fbc2eb, #a6c1ee);
            color: #4b0082;
            text-align: left;
        }
        .chat-container {
            max-height: 500px;
            overflow-y: auto;
            padding: 1rem;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #ffffff;
        }
        .send-button button {
            background-color: #4b0082;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 10px;
            margin-top: 0.5rem;
        }
        </style>
    """, unsafe_allow_html=True)

    st.title("💬 AI Mental Medical Chatbot")
    st.write("Hi there! I’m here to listen. How can I help you today?")

    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []

    st.markdown('<div class="chat-container">', unsafe_allow_html=True)

    for sender, message in st.session_state.chat_history:
        if sender == "You":
            st.markdown(f'<div class="chat-message user-message">{message}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="chat-message bot-message">{message}</div>', unsafe_allow_html=True)

    st.markdown('</div>', unsafe_allow_html=True)

    user_input = st.text_input("Type your message here:", "")
    send_button = st.button("Send")
    if send_button and user_input != "":
      intent = predict_class(user_input)
      bot_response = get_response(intent, intents)
  
      st.session_state.chat_history.append(("You", user_input))
      st.session_state.chat_history.append(("Bot", bot_response))
  
      st.rerun()  # Updated


if __name__ == "__main__":
    main()
